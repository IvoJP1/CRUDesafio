insert into tbaluno(data_nascimento, email,endereco,nome,periodo) values("2009-06-16","luis@teste.com","Rua Melo Peixoto","Luis Felipe","Diurno");
insert into tbaluno(data_nascimento, email,endereco,nome,periodo) values("2001-10-31","pedro@teste.com","Rua Restinga","Pedro Henrique","Vespertino");
insert into tbaluno(data_nascimento, email,endereco,nome,periodo) values("2000-04-09","erica@teste.com","Avenida Celso Garcia","Erica Silva","Noturno");
insert into tbaluno(data_nascimento, email,endereco,nome,periodo) values("1990-07-10","duda@teste.com","Alamenda Santos","Maria Eduarda","Noturno");
insert into tbaluno(data_nascimento, email,endereco,nome,periodo) values("1950-03-18","gabriel@teste.com","Rua do Programador","Gabriel Lima","Diurno");